/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiler.assignment.pkg1;
import java.io.PrintStream;
import java.util.Scanner;

/**
 *
 * @author Tushar
 */
public class CompilerAssignment1 {
    

   static void id_check()
    {
       Scanner scan = new Scanner(System.in); 
    int flag=0;
    
        System.out.println("Enter Id: ");
        String ar=scan.next();
        
       
       if(ar.length()==9)
       {
                  
    if( ar.charAt(0)=='0' && ar.charAt(1)=='1' && ar.charAt(2)=='1' )
    {
        
        if(ar.charAt(5)=='1' || ar.charAt(5)=='2' || ar.charAt(5)=='3' )
        {
            if(ar.charAt(6)=='0' && ar.charAt(7)=='0' && ar.charAt(8)=='0')
            {
               flag=0;
            }
            
            else 
                flag=1;
        }

    }


    if( flag == 1 )
    {
        System.out.println("Accepted");
    }

    else
            System.out.println("Not Accepted");

       }
       
       else
       {
           System.out.println("Not Accepted by length");
       }
           
       
    
    }
    
   
   static void complex_number()
   {
       Scanner scan= new Scanner(System.in);
    int i,k,j;
   
    int count=0;
       System.out.println("Input");
       String arr=scan.next();
    int len=arr.length();



    if((arr.charAt(0)>='a' && arr.charAt(0)<='z')  || (arr.charAt(0)>='1' && arr.charAt(0)<='9'))
    {
        for(i=1; i<len; i++)
        {

            if(arr.charAt(i)== '=')
            {
                for(k=1; k<len; k++)
                {
                    if(arr.charAt(k)=='+')
                    {

                        for(j=1; j<len; j++)
                        {

                            if(arr.charAt(j)=='i')
                            {

                                if(((arr.charAt(j-1)>='a' && arr.charAt(j-1)<='z')  || (arr.charAt(j-1)>='1' && arr.charAt(j-1)<='9')) || ((arr.charAt(j+1)>='a' && arr.charAt(j+1)<='z')  || (arr.charAt(j+1)>='1' && arr.charAt(j+1)<='9')))
                                {

                                    count=1;
                                }
                            }

                        }
                    }

                }
            }



            if(arr.charAt(i)== '+')
            {
                for(j=1; j<len; j++)
                {

                    if(arr.charAt(j)=='i')
                    {
    if (((arr.charAt(j-1)>='a' && arr.charAt(j-1)<='z')  || (arr.charAt(j-1)>='1' && arr.charAt(j-1)<='9')) || ((arr.charAt(j+1)>='a' && arr.charAt(j+1)<='z')  || (arr.charAt(j+1)>='1' && arr.charAt(j+1)<='9')))
                        {

                            count=1;
                        }

                    }

                }
            }

        }
    }

         if(count==1)
           System.out.println("Accepted");
    else
           System.out.println("Not Accepted");

    }
   

   

   
   
   
   static void regular_expression()
   {
       Scanner scan = new Scanner(System.in); 
       
    int i;
    int flag=0;
       System.out.println("Input: ");
    String st=scan.nextLine();
    int len=st.length();
           
    if(len<3)
    {
        flag=0;
         if(flag==1)
           System.out.println("Accepted");
    else
           System.out.println("Not Accepted");

      
    }
    
    else if(len==3)
    {
        if(st.charAt(0)>='1' && st.charAt(0)<='9')
        {
            if(st.charAt(1)>='A' && st.charAt(1)<='Z')
            {
                if(st.charAt(2)>='0' && st.charAt(2)<='9' )
            {
                flag=1;
            }
            }
        }
        
    if(flag==1)
           System.out.println("Accepted");
    else
           System.out.println("Not Accepted");

        
       
    }
    
    else 
    {
        
        
        
    if(st.charAt(0)>='1' && st.charAt(0)<='9')
    {
        if(st.charAt(1)>='A' && st.charAt(1)<='Z')
        {
            
            if(st.charAt(2)>='A' && st.charAt(2)<='Z'  || st.charAt(2)>='a' && st.charAt(2)<='z' )
            {
                flag=0;
            }

            
            else
            {
                flag=1;

                for(i=3; i<len; i++)
                {
                    if(st.charAt(i)>='A' && st.charAt(i)<='Z'  || st.charAt(i)>='a' && st.charAt(i)<='z'  || st.charAt(i)>='1' && st.charAt(i)<='9')
                    {
                        flag=1;
                    }
                }
            }
        }
        else 
            flag=0;
    }


    if(flag==1)
           System.out.println("Accepted");
    else
           System.out.println("Not Accepted");

        
    }
    
    

    }
    
    
   
   
   static void integer_float()
   {
       Scanner scan= new Scanner(System.in);
       System.out.println("Input: ");
       String s=scan.nextLine();
   int duplicate=0;
   int flag=1;
   int i;
   int len=s.length();
   for(i=0;i<len;i++)
   {
       if(s.charAt(i)>='a' && s.charAt(i)<='z'  || s.charAt(i)>='A' && s.charAt(i)<='z'  || s.charAt(i)== '*' || s.charAt(i)== '/' || s.charAt(i)=='@' || s.charAt(i)=='#' || s.charAt(i)== '$' || s.charAt(i)=='&')
       {
           flag=0;
       }
       if(s.charAt(i)=='.')
        duplicate++;

   }

    if(s.charAt(len-1)=='.')
    {
        flag=0;
    }

    if((flag==1 && duplicate==1)  || (flag==1 && duplicate==0))
           System.out.println("Accepted");
    else
           System.out.println("Not Accepted");
   }
    
   
   
   
   static void password()
   {
       
   Scanner scan=new Scanner(System.in);
       System.out.println("Input: ");
   String s=scan.next();
   int len=s.length();
   int i;
   int flag=1;
   int upcase=0, lowcase=0, dig=0, spchar=0;

   if(len<8)
    flag=0;

   if(s.charAt(len-1)=='@' || s.charAt(len-1)=='#' || s.charAt(len-1)=='$' || s.charAt(len-1)=='&')
   {
       spchar=1;
   }


   for(i=0;i<len;i++)
   {
    if(s.charAt(i)>='A' && s.charAt(i)<='Z')
        upcase++;

    else if(s.charAt(i)>='a' && s.charAt(i)<='z')
        lowcase++;

    else if(s.charAt(i)>='1' && s.charAt(i)<='9')
        dig++;
   }


   if(flag==1 && upcase>0 && lowcase>0 && dig>0 && spchar ==1)
   {
       System.out.println("Accepted");
   }
   else
           System.out.println("Not Accepted");

   }
    
   
   /////////////MENU///////////////
   static void menu()
   {
       System.out.println("\n\n1. ID Matching\n2. Complex Number\n3. Expression String Matching\n4. Integer Float\n5. Password Matching\n0. EXIT\n");
   }
   
   
   
    public static void main(String[] args) {
     
        Scanner scan= new Scanner(System.in);
        
        
       while(true)
       {
           menu();
           System.out.println("Enter Choice: ");
           int ch=scan.nextInt();
           
           if(ch==1)
           {
               id_check();
             
           }
           else if (ch==2)
           {
               complex_number();
           }
           else if (ch==3)
           {
               regular_expression();
           }
           else if (ch==4)
           {
               integer_float();
           }
           else if(ch==5)
           {
               password();
           }
           else if(ch==0)
           {
           System.exit(0);
           }
           
       }
    }
    
}
