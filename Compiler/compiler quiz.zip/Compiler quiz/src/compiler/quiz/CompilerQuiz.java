/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiler.quiz;

import java.util.Scanner;

/**
 *
 * @author Tushar
 */
public class CompilerQuiz {

    public static void compile()
    {
          Scanner scan= new Scanner(System.in);
        
         String s=scan.next();
    
    int flag=0;

    String tag_s ="";
    int i,j,ch = 0;
    if(s.charAt(0)!='<')
    {

        System.out.println("invalid");
    }

    else
    {
        for(i=0; s.charAt(i)!='>'; i++)
        {
            if(s.charAt(i)=='>')
            {
                ch=i;
                break;
            }
        }

            String[] st= s.split(">");
            
            tag_s=st[0];
            
            tag_s=tag_s+">";
            //System.out.println(tag_s);
       
        


        if(s.charAt(ch+1)=='0' && s.charAt(ch+2)=='0' && s.charAt(ch+3)=='0' )
        {

            System.out.println("invalid");
        }
        else
        {
            int ch_dot = 0;
            for(i=0; i<s.length(); i++)
            {
                if(s.charAt(i)=='.')
                {
                    ch_dot=i;
                    break;
                }
            }


            for(i=ch+4; i<ch_dot; i++)
            {
                if((s.charAt(i)>='a' && s.charAt(i)<='z')   ||  (s.charAt(i)>='A' && s.charAt(i)<='Z'))
                {
                    flag=1;
                }
                else
                    flag=0;

            }

            if(flag==1)
            {
                int flag1=0;
                if(s.charAt(ch_dot+1)=='_')
                {
                    if((s.charAt(ch_dot+ 2)>='a' && s.charAt(ch_dot+ 2)<='z') || (s.charAt(ch_dot+ 2)>='A' && s.charAt(ch_dot+ 2)<='Z')
                            || (s.charAt(ch_dot+ 2)>='0' && s.charAt(ch_dot+ 2)<='9'))
                    {
                        if(s.charAt(ch_dot+3)=='@')
                        {
                            for(i=ch_dot+4,j=0; i<s.length(); i++,j++)
                            {
                                if(s.charAt(i)==tag_s.charAt(j))
                                {
                                    flag1=1;
                                }
                                else
                                    flag1=0;
                            }


                            if(flag1==1)
                                System.out.println("valid");
                            else
                                System.out.println("invalid");

                        }
                        else
                                System.out.println("invalid");

                    }
                    else
                                System.out.println("invalid");

                }
                else
                                System.out.println("invalid");


            }
            else
                System.out.println("invalid");

        }



    }


    }
    
    
    
    public static void main(String[] args) {
      
            while(true)
            {
                compile();
            }
        
    }
    
}
