package assignment.pkg2;

import java.util.Scanner;

 class data{
    static String ar[][]= new String[100][3];
    static int ii=0;
}
public class Assignment2 {
    
     Scanner scan = new Scanner(System.in);
    static void menu()
    {
        System.out.println("\n1. Insert\n2. Find\n3. Delete\n4. Show Specific\n5. Show All\n6. Update ");
        System.out.println("\nChoice: ");
    }

    
    
    
    static String type_function(String s)
    {
        String[] st= s.split(" ");
        
      return st[0];
    }
    static void insert()
    {
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Input: ");
        String s= scan.nextLine();
        String type;
        
        type=type_function(s);
        type=type+" ";
        
        String s2= s.replaceAll(type, "");
        s2=s2.replaceAll(";", "");
  
        int coma_count= ( s2.split(",", -1).length ) - 1;
        int equal_count=(s2.split("=", -1).length) -1;
        
        
        String name1 = null,name2= null;
        String val1="NULL",val2="NULL";
        int i,j;
       
        if(coma_count>0)
        {
            String[] coma_split= s2.split(",");
              
                String left=coma_split[0];
                String right=coma_split[1];
                
                int left_equal_count=(left.split("=", -1).length )-1;
                int right_equal_count=(right.split("=", -1).length )-1;
                
                
                if(left_equal_count==1)
                {
                   String[] x_split= left.split("=");
                   
                   name1=x_split[0];
                   val1=x_split[1];
                }
                else 
                {
                    name1=left;
                    
                }
                
                
                data.ar[data.ii][0]=name1;
                data.ar[data.ii][2]=val1;
                data.ar[data.ii][1]=type;
        
                
                data.ii++;
                
                
                if(right_equal_count==1)
                {
                   String[] x_split= right.split("=");
                   
                   name2=x_split[0];
                   val2=x_split[1];
                }
                else 
                {
                    name2=right;
                    
                }
                data.ar[data.ii][0]=name2;
                data.ar[data.ii][2]=val2;
                data.ar[data.ii][1]=type;
                
                
          
        }
        
        else 
        {
          int e_count=(s2.split("=", -1).length )-1;
          if(e_count==1)
          {
             String[] x_split= s2.split("=");
             
             name1=x_split[0];
             val1=x_split[1];
          }
          else 
              name1=s2;
          
          
          
                data.ar[data.ii][0]=name1;
                data.ar[data.ii][2]=val1;
                data.ar[data.ii][1]=type;
          
            
        }
        
        data.ii++;
    }
    
    static void find()
    {
        Scanner scan=new Scanner(System.in);
        int flag=1;
        
        int t=-1,n=-1,v=-1;
        System.out.println("Find Input: ");
        
            String st=scan.nextLine();
            
            for(int i=0;i<data.ii;i++)
            {
               t= data.ar[i][1].compareTo(st);
               n=data.ar[i][0].compareTo(st);
               v=data.ar[i][2].compareTo(st);
               
               
               if(t==0||v==0||n==0)
               {
                   flag=0;
                   break;
               }
            }
        
            
        
        if(flag==0)
        {
            System.out.println("\nFOUND\n");
        }
        else 
            System.out.println("\nNOT FOUND\n");
    }
    static void delete()
    {
        
        Scanner scan=new Scanner(System.in);
        for(int i=0;i<data.ii;i++)
        {
            System.out.println(i+1 +" "+ data.ar[i][0]+ " "+ data.ar[i][1]+ " "+  data.ar[i][2]+ " ");
        }
        
        System.out.println("Enter Serial to Remove\n");
        int ch=scan.nextInt();
        
        ch=ch-1;
        int i,j;
        for( i=ch,j=ch+1;i<data.ii-1;i++,j++)
        {
            data.ar[i][0]=data.ar[j][0];
            data.ar[i][1]=data.ar[j][1];
            data.ar[i][2]=data.ar[j][2];
        }
        
        data.ar[i][0]=null;
        data.ar[i][1]=null;
        data.ar[i][2]=null;
        
        
        data.ii=data.ii-1;
        
        System.out.println("Delete Successful..!!");
    }
    static void Show_Specific()
    {
         Scanner scan=new Scanner(System.in);
        System.out.println("Choose any serial between 1 to "+data.ii );
        int ch=scan.nextInt();
        
      for(int i=0;i<3;i++)
      {
          System.out.print(data.ar[ch-1][i]+ " ");
      }
      
        System.out.println("\n\n");
    }
    static void Show_All()
    {
        int i;
        for(i=0;i<data.ii;i++)
        {
            System.out.println(i+1 +" "+ data.ar[i][0]+ " "+ data.ar[i][1]+ " "+  data.ar[i][2]+ " ");
        }
    }
    static void update()
    {
        Scanner scan=new Scanner(System.in);
        
        System.out.println("Update Value between 1 to "+data.ii +"serial" );
        
        int ch=scan.nextInt();
        
        System.out.println("Update Value for "+ data.ar[ch-1][0]+"\n");
        
        String s=scan.next();
        data.ar[ch-1][2]=s;
        
        
        System.out.println("Update Succesful..!!\n1"
                + "");
        
        
    }
    public static void main(String[] args) {
      
       Scanner scan = new Scanner(System.in);

        while(true)
        {
            menu(); 
            int ch=scan.nextInt();
            
            if(ch==1)
                insert();
            else if(ch==2)
                find();
            else if(ch==3)
                delete();
            else if(ch==4)
                Show_Specific();
            else if(ch==5)
                Show_All();
            else if(ch==6)
                update();
            else 
                System.out.println("Wrong input..!!");
         
        }
    }
    
}
